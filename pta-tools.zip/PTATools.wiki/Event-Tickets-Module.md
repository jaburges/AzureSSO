# Event Tickets Module

Sell event tickets as WooCommerce products with a visual seating designer, seat selection, QR code tickets, Apple Wallet support, and event check-in.

---

## Overview

| Feature | Description |
|---------|-------------|
| **Custom Product Type** | "Event Ticket" product type in WooCommerce |
| **Seating Designer** | Visual layout for venues (TEC venues with seating) |
| **Seat Selection** | Customers pick seats on the product page |
| **QR Code Tickets** | Generated tickets with QR codes |
| **Apple Wallet** | Add to Apple Wallet for supported events |
| **Check-in** | Dedicated check-in page for events |
| **TEC Integration** | Links to The Events Calendar events and venues |

---

## Requirements

- **WooCommerce** plugin installed and activated
- **The Events Calendar** plugin (for venues and events)
- No Azure credentials required for basic ticket sales

---

## Configuration

**Location:** Azure Plugin → Event Tickets (and Tickets → Check-in for check-in)

1. Enable the **Event Tickets** module on the main dashboard.
2. Create a product and set **Product type** to **Event Ticket**.
3. Use the Event, Seating, and Ticket Settings tabs to set venue, date, seating layout, and ticket options.
4. Customers see the seating map on the single product page, select seats, and add to cart. Tickets (with QR codes and optional Apple Wallet) are generated after purchase.

**Check-in:** Use Azure Plugin → Tickets → Check-in to scan or look up tickets and mark attendees as checked in.

---

## Notes

- Event Tickets are product-based; no shortcodes are required for the main flow.
- Seating layouts are designed per venue when using TEC venues.
