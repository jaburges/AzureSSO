# PTA Tools - Documentation

Welcome to the PTA Tools plugin documentation! This guide covers integration with Microsoft 365 and WooCommerce. Perfect for PTAs, nonprofits, and organizations. (Also known as **Microsoft WP**.)

## 📚 Table of Contents

### Getting Started
- **[Prerequisites](Prerequisites)** - What you need before installing
- **[Quick Start](Quick-Start)** - Get up and running in 15 minutes
- **[Installation](Installation)** - Detailed installation guide
- **[Azure App Registration](Azure-App-Registration)** - Setting up your Azure app

### Module Guides
- **[SSO Authentication](SSO-Module)** - Azure AD Single Sign-On
- **[Backup to Azure](Backup-Module)** - Automated backups to Azure Storage
- **[Calendar Embed](Calendar-Embed-Module)** - Embed Outlook calendars
- **[Calendar Sync (TEC)](Calendar-Sync-Module)** - Sync with The Events Calendar
- **[Email via Graph API](Email-Module)** - Send emails through Microsoft
- **[Newsletter](Newsletter-Module)** - Visual email newsletters with analytics
- **[PTA Roles](PTA-Roles-Module)** - Role and department management
- **[Classes (WooCommerce)](Classes-Module)** - Class products with TEC integration
- **[Event Tickets](Event-Tickets-Module)** - Seating, QR tickets, Apple Wallet, check-in
- **[Auction](Auction-Module)** - Auction products with bidding and Buy It Now
- **[Upcoming Events](Upcoming-Events-Module)** - Display upcoming events
- **[OneDrive Media](OneDrive-Module)** - OneDrive media integration

### Advanced Topics
- **[Advanced Configuration](Advanced-Configuration)** - Power user settings
- **[Shortcode Reference](Shortcode-Reference)** - All shortcodes in one place
- **[Troubleshooting](Troubleshooting)** - Common issues and solutions

### Development
- **[Contributing](Contributing)** - How to contribute to the project
- **[Development Setup](Development)** - Setting up a dev environment

---

## 🎯 What This Plugin Does

Microsoft PTA provides deep integration between WordPress and Microsoft 365, enabling:

| Feature | Benefit |
|---------|---------|
| **SSO Login** | Users sign in with their Microsoft 365 accounts |
| **Automated Backups** | Never lose data with Azure Blob Storage backups |
| **Calendar Integration** | Display and sync Outlook calendars |
| **Graph API Email** | Send reliable emails through Microsoft |
| **Newsletter** | Visual email editor with campaigns, analytics, and spam testing |
| **Role Management** | Organize volunteers with O365 group sync |
| **Class Products** | Sell classes with automatic event creation |
| **Event Tickets** | Seating designer, QR tickets, Apple Wallet, check-in |
| **Auction** | Bidding, max bid, Buy It Now, winner checkout via WooCommerce |
| **Media Integration** | Use OneDrive files directly in WordPress |

---

## 🚀 Setup Wizard

**New in v3.0!** First-time users are guided through a step-by-step setup wizard that helps you:

1. **Configure your organization** - Set your domain, name, and admin email
2. **Select modules** - Enable only what you need
3. **Connect to Azure** - Enter and validate your Azure App credentials
4. **Configure each module** - Set up backup storage, PTA roles, SSO options, etc.

The wizard runs once per site; complete it to dismiss the banner.

---

## 🆓 Free for Nonprofits

Microsoft offers generous programs for qualifying nonprofits:

### Microsoft 365 Business Basic (Free)
- **300 free licenses** for email, Teams, SharePoint, OneDrive
- [Apply at Microsoft Nonprofits](https://nonprofit.microsoft.com/en-us/getting-started)

### Azure Credits ($3,500/year)
- **$3,500 annual Azure credits** for cloud services
- Perfect for backups, App Registrations, and more
- [Apply for Azure for Nonprofits](https://www.microsoft.com/en-us/nonprofits/azure)

---

## 📊 Dashboard Widgets

When modules are enabled, stats appear on your WordPress admin dashboard:

- **PTA Tools Overview** - Quick view of enabled modules
- **SSO Statistics** - User logins and sync status
- **PTA Roles Overview** - Departments, roles, and assignments
- **Newsletter Statistics** - Subscribers, campaigns, open rates
- **Event Tickets** - Ticket and check-in stats
- **Auction** - Active auctions and recent bids
- **Backup Status** - Last backup and monthly count

---

## 🚀 Quick Links

- **[GitHub Repository](https://github.com/jaburges/AzureSSO)** - Source code and issues
- **[Quick Start Guide](Quick-Start)** - Get started fast
- **[Troubleshooting](Troubleshooting)** - Fix common issues

---

## 📊 Plugin Version

**Current Version:** 3.35  
**Requires WordPress:** 5.0+  
**Requires PHP:** 7.4+  
**Requires WooCommerce:** For Classes, Event Tickets, and Auction  
**License:** GPL v2 or later

---

*Need help? Check our [Troubleshooting](Troubleshooting) guide or [open an issue](https://github.com/jaburges/PTATools/issues).*
