# Newsletter Module

Create, design, and send beautiful email newsletters to your WordPress users and custom subscriber lists.

---

## 📋 Overview

| Feature | Description |
|---------|-------------|
| **Visual Email Editor** | GrapesJS-powered drag-and-drop editor |
| **Multiple Sending Services** | Mailgun, SendGrid, Amazon SES, SMTP, Office 365 |
| **Subscriber Lists** | WordPress users, custom lists, role-based targeting |
| **Analytics Dashboard** | Track opens, clicks, bounces, and more |
| **Webhook Integration** | Real-time delivery tracking via webhooks |
| **Template Library** | Pre-built and custom templates |

---

## ⚙️ Configuration

### Location
**Azure Plugin → Newsletter → Settings**

### Sending Services

| Service | Features |
|---------|----------|
| **Mailgun** | API-based, excellent deliverability, detailed webhooks |
| **SendGrid** | API-based, marketing features, good analytics |
| **Amazon SES** | Cost-effective, high volume, AWS integration |
| **Custom SMTP** | Any SMTP server (Gmail, custom mail servers) |
| **Office 365** | Uses Azure Graph API (requires Mail.Send permission) |

### Mailgun Setup

1. Create account at [mailgun.com](https://www.mailgun.com)
2. Add and verify your sending domain
3. Copy **API Key** from Settings → API Keys
4. Copy **Domain** (e.g., `mail.yourdomain.com`)
5. Select **Region** (US or EU)
6. *Optional:* Copy **Webhook Signing Key** for enhanced security

### Webhook Configuration (Mailgun)

Configure webhooks in Mailgun Dashboard → Sending → Webhooks:

**Webhook URL:**
```
https://yourdomain.com/wp-json/azure-plugin/v1/newsletter/webhook/mailgun
```

**Events to configure:**
- `accepted` - Email accepted by Mailgun
- `delivered` - Successfully delivered
- `opened` - Recipient opened email
- `clicked` - Recipient clicked a link
- `complained` - Marked as spam
- `temporary_fail` - Soft bounce
- `permanent_fail` - Hard bounce

---

## 📧 Email Editor

### Location
**Azure Plugin → Newsletter → New Campaign**

### 4-Step Workflow

1. **Setup** - Name, subject line, from address
2. **Design** - Visual drag-and-drop editor
3. **Recipients** - Select audience
4. **Review & Send** - Preview and schedule/send

### Editor Features

#### Left Sidebar - Content Blocks

| Block | Description |
|-------|-------------|
| **Text** | Rich text with formatting |
| **Image** | Single image with link |
| **Button** | CTA button with customizable colors |
| **Divider** | Horizontal separator |
| **Spacer** | Adjustable vertical spacing |
| **Social** | Social media icon links |
| **Latest Posts** | Dynamic WordPress posts |
| **Upcoming Events** | TEC events integration |
| **HTML** | Custom HTML code |

#### WordPress Integration Blocks

| Block | Description |
|-------|-------------|
| **PTA Directory** | Staff/volunteer directory |
| **Open Positions** | Available volunteer roles |
| **Department Roles** | Roles by department |
| **Org Chart** | Organization structure |
| **Department VP** | Department leadership |

#### Right Sidebar - Settings Panel

When you select any block, the Settings panel shows configuration options:

| Block Type | Available Settings |
|------------|-------------------|
| **Latest Posts** | Post count, category, show image, show excerpt |
| **PTA Directory** | Department, columns, show empty roles |
| **Open Positions** | Limit, department filter |
| **Button** | Text, URL, colors |
| **Image** | Source, alt text, link, width |
| **HTML** | Custom HTML code editor |
| **Spacer** | Height in pixels |

#### Styles Panel

Apply styling to selected elements:
- Typography (font, size, weight)
- Colors (text, background)
- Spacing (padding, margin)
- Alignment
- Borders

### Device Preview

| Mode | Width | Use |
|------|-------|-----|
| **Desktop** | Full width | Standard view |
| **Tablet** | 768px | Tablet preview |
| **Mobile** | 375px | Phone preview |

---

## 📊 Analytics & Statistics

### Location
**Azure Plugin → Newsletter → Statistics**

### Overview Metrics

| Metric | Description |
|--------|-------------|
| **Emails Sent** | Total emails dispatched |
| **Delivery Rate** | Successfully delivered (%) |
| **Open Rate** | Unique opens (%) |
| **Click Rate** | Unique clicks (%) |
| **Bounce Rate** | Failed deliveries (%) |
| **Unsubscribes** | Total unsubscribe count |
| **Complaints** | Spam reports |

### Event Tracking

All events are tracked via webhooks:

| Event | Tracked Data |
|-------|--------------|
| `sent` | Email accepted for delivery |
| `delivered` | Successful delivery to inbox |
| `opened` | Email opened (via tracking pixel) |
| `clicked` | Link clicked (with URL) |
| `bounced` | Delivery failed (soft/hard) |
| `complained` | Marked as spam |
| `unsubscribed` | User unsubscribed |

### Activity Chart

Visual timeline showing:
- Sent volume
- Delivered count
- Opens over time
- Clicks over time
- Bounces

### Top Links Report

For each campaign, see which links were clicked most.

---

## 👥 Subscriber Lists

### Location
**Azure Plugin → Newsletter → Lists**

### List Types

| Type | Description |
|------|-------------|
| **All WordPress Users** | Every registered user |
| **Role-Based** | Users with specific roles |
| **Custom List** | Manually managed subscribers |

### Bounce Handling

- **Soft bounces**: Tracked, retried
- **Hard bounces**: Auto-blocked after 3 failures
- **Complaints**: Immediately blocked

---

## 🧪 Testing

### Test Connection

Verify your sending service credentials are correct:
1. Go to **Newsletter → Settings**
2. Click **Test Connection**
3. Success = credentials valid

### Send Test Email

Send a real test email to verify full delivery:
1. Go to **Newsletter → Settings**
2. Enter recipient email in **Send Test Email** section
3. Click **Send Test Email**
4. Check inbox for test message

---

## 📝 Templates

### Location
**Azure Plugin → Newsletter → Templates**

### Default Templates

- **Blank** - Start from scratch
- **Simple Announcement** - Basic text layout
- **Newsletter** - Multi-section with header/footer
- **Event Invitation** - Event-focused design

### Custom Templates

Save any design as a template:
1. Design your email in the editor
2. Click **Save as Template**
3. Name your template
4. Reuse for future campaigns

---

## 🔧 Settings Reference

### General Settings

| Setting | Description |
|---------|-------------|
| **Sending Service** | Mailgun, SendGrid, SES, SMTP, O365 |
| **From Address(es)** | Verified sender email(s) |
| **Rate Limit** | Emails per hour (prevent throttling) |
| **Track Opens** | Enable open tracking pixel |
| **Track Clicks** | Enable click tracking |

### Bounce Handling

| Setting | Description |
|---------|-------------|
| **Enable Bounce Processing** | Auto-process bounced emails |
| **Bounce Mailbox** | Email to receive bounces (IMAP) |

### Archive Settings

| Setting | Description |
|---------|-------------|
| **Create WP Pages** | Auto-create page for each newsletter |
| **Archive Category** | Category for newsletter pages |

---

## 🔒 Security

### Webhook Verification

Mailgun webhooks are verified using HMAC signature:
- Configure **Webhook Signing Key** in settings
- All webhook requests are validated
- Timestamp checked to prevent replay attacks

### Unsubscribe Protection

- Unique token per subscriber
- One-click unsubscribe links
- GDPR compliant

---

## 🔧 Troubleshooting

### "Test email not sending"

1. Verify API key is correct
2. Check domain is verified in sending service
3. Ensure from address is valid
4. Check rate limits not exceeded

### "Webhooks not recording"

1. Verify webhook URL is accessible
2. Check webhook signing key matches
3. Review server error logs
4. Ensure SSL certificate is valid

### "High bounce rate"

1. Clean your email list
2. Verify email addresses before adding
3. Remove hard bounces promptly
4. Monitor complaint rate

### "Emails going to spam"

1. Configure SPF record for domain
2. Configure DKIM signing
3. Use consistent from address
4. Include unsubscribe link
5. Avoid spam trigger words

---

## 📊 Database Tables

The Newsletter module creates these tables:

| Table | Purpose |
|-------|---------|
| `azure_newsletters` | Campaign data |
| `azure_newsletter_queue` | Send queue |
| `azure_newsletter_stats` | Event tracking |
| `azure_newsletter_lists` | Subscriber lists |
| `azure_newsletter_list_members` | List memberships |
| `azure_newsletter_bounces` | Bounce records |
| `azure_newsletter_templates` | Saved templates |

### Database Management

**Azure Plugin → Newsletter → Settings → Database Management**

- **Create Tables** - Create/repair tables (safe)
- **Reset Data** - Delete all newsletter data (destructive!)

---

## ➡️ Related

- **[Email via Graph](Email-Module)** - wp_mail() integration
- **[PTA Roles Module](PTA-Roles-Module)** - Dynamic content blocks
- **[Shortcode Reference](Shortcode-Reference)** - Available shortcodes
- **[Troubleshooting](Troubleshooting)** - Common issues



